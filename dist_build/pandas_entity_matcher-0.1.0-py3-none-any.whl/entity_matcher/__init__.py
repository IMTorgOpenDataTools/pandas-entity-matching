from entity_matcher.config import field_config
from entity_matcher.EntityMatcher import EntityMatcher



__all__ = [
    "field_config",
    "EntityMatcher"
    ]